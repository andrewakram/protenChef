<!--begin::Footer-->
<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <!--begin::Container-->
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between"
    style="max-height: 20px;!important;">
        <!--begin::Copyright-->
        <div class=" order-2 order-md-1">
            <span class=" fw-bold me-1" style="color:#F48120">2022 ©</span>
            <a href="http://tesolutionspro.com" target="_blank" class="text-grey-800 text-hover-primary" style="color:#F48120">
                جميع الحقوق محفوظة</a>
        </div>
        <!--end::Copyright-->
        <!--begin::Menu-->
        <ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">
            <li class="menu-item">
                <a href="http://tesolutionspro.com" target="_blank" class="menu-link px-2" style="color:#00ccff">
                    <b style="font-size: large">TES &nbsp;&nbsp;&nbsp;</b>
                    شركة مصرية متخصصة في برمجة تطبيقات الجوال و المواقع الإلكترونية
                </a>
            </li>
{{--            <li class="menu-item">--}}
{{--                <a href="http://tesolutionspro.com/support" target="_blank" class="menu-link px-2">Support</a>--}}
{{--            </li>--}}
{{--            <li class="menu-item">--}}
{{--                <a href="https://1.envato.market/EA4JP" target="_blank" class="menu-link px-2">Purchase</a>--}}
{{--            </li>--}}
        </ul>
        <!--end::Menu-->
    </div>
    <!--end::Container-->
</div>
<!--end::Footer-->
